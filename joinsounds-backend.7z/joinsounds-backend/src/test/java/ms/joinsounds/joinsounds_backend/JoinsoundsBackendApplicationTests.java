package ms.joinsounds.joinsounds_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoinsoundsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
