package ms.joinsounds.joinsounds_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoinsoundsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoinsoundsBackendApplication.class, args);
	}

}
